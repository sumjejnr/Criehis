# CASE 07 — 사라진 마지막 밤

모바일 중심의 한국어 추리 게임 정적 웹사이트입니다. HTML/CSS/JavaScript만 사용하며 별도 서버나 빌드 과정이 필요하지 않습니다.

## 로컬에서 실행
`index.html`을 브라우저에서 열면 됩니다. 이미지와 폰트는 외부 URL을 사용하므로 인터넷 연결이 필요합니다.

## GitHub Pages로 배포
1. GitHub에서 새 Public repository를 만듭니다.
2. `index.html`, `style.css`, `script.js`를 저장소 최상위(root)에 업로드합니다.
3. 저장소의 **Settings → Pages**로 이동합니다.
4. **Deploy from a branch**를 선택합니다.
5. Branch는 `main`, 폴더는 `/ (root)`로 선택하고 Save를 누릅니다.
6. 잠시 기다리면 `https://계정이름.github.io/저장소이름/` 주소로 공개됩니다.

## 수정하기
- 등장인물과 정답: `script.js` 상단의 `suspects` 배열 및 `selected==='S05'` 부분
- 증거: `evidence` 배열
- 색상/레이아웃: `style.css`의 `:root` 변수와 각 클래스
- 사건 소개/페이지 구조: `index.html`

## 참고
- 수첩 내용은 현재 기기의 브라우저 `localStorage`에 저장됩니다. 다른 기기와 동기화되지 않습니다.
- 데모 스토리와 인물은 창작 설정입니다.
- 정답은 데모상 한유리(S05)로 설정되어 있습니다.
- 실제 운영용 비밀 콘텐츠 보호가 필요한 경우 서버 측 인증/검증을 추가해야 합니다. 정적 사이트의 JavaScript 코드는 방문자가 확인할 수 있습니다.
